package com.bump.spoofer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Newest-first JSON history kept in the app's private storage (max 200 entries). */
class HistoryStore(ctx: Context) {
    private val file = File(ctx.filesDir, "history.json")

    @Synchronized
    fun all(): JSONArray =
        if (file.exists()) try { JSONArray(file.readText()) } catch (e: Exception) { JSONArray() }
        else JSONArray()

    @Synchronized
    fun add(entry: JSONObject) {
        val old = all()
        val out = JSONArray()
        out.put(entry.put("t", System.currentTimeMillis()))
        for (i in 0 until minOf(old.length(), 199)) out.put(old.get(i))
        file.writeText(out.toString())
    }

    @Synchronized
    fun clear() {
        file.delete()
    }
}
