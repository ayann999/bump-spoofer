package com.bump.spoofer

import android.content.Context
import android.location.Criteria
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.SystemClock
import android.util.Log
import org.json.JSONObject
import java.util.Arrays
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Feeds fake fixes to Android's test providers once per second.
 * Works without root as long as this app is chosen under
 * Developer options -> "Select mock location app".
 */
class MockLocationEngine(ctx: Context) {
    enum class Mode { IDLE, TELEPORT, ROUTE }

    private val tag = "BumpEngine"
    private val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val providers = arrayOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
    private val exec = Executors.newSingleThreadScheduledExecutor()

    private var started = false
    private var mode = Mode.IDLE
    private var pos: LatLng? = null
    private var bearing = 0f
    private var speedKmh = 5.0
    private var paused = false

    private var route: List<LatLng> = emptyList()
    private var cum = DoubleArray(0)      // cumulative metres at each route point
    private var progress = 0.0
    private var dir = 1
    private var loop = false
    private var lastTick = SystemClock.elapsedRealtime()

    init {
        exec.scheduleAtFixedRate({
            try { tick() } catch (e: Exception) { Log.e(tag, "tick failed", e) }
        }, 1000, 1000, TimeUnit.MILLISECONDS)
    }

    /** Registers the test providers. Throws SecurityException if we are not the mock location app. */
    @Synchronized
    fun enable() {
        if (started) return
        for (p in providers) {
            try { lm.removeTestProvider(p) } catch (e: Exception) { /* not registered yet */ }
            lm.addTestProvider(p, false, false, false, false, true, true, true,
                Criteria.POWER_LOW, Criteria.ACCURACY_FINE)
            lm.setTestProviderEnabled(p, true)
        }
        started = true
    }

    /** Removes the test providers: the phone goes back to its real GPS. */
    @Synchronized
    fun disable() {
        for (p in providers) {
            try { lm.removeTestProvider(p) } catch (e: Exception) { /* ignore */ }
        }
        started = false
        mode = Mode.IDLE
        pos = null
        route = emptyList()
        cum = DoubleArray(0)
        paused = false
    }

    fun shutdown() {
        disable()
        exec.shutdownNow()
    }

    @Synchronized
    fun teleport(lat: Double, lng: Double) {
        enable()
        pos = LatLng(lat, lng)
        mode = Mode.TELEPORT
        route = emptyList()
        cum = DoubleArray(0)
        paused = false
        push()
    }

    @Synchronized
    fun startRoute(points: List<LatLng>, kmh: Double, loop: Boolean) {
        require(points.size >= 2) { "A route needs at least 2 points" }
        require(kmh.isFinite()) { "Invalid speed" }
        enable()
        val c = DoubleArray(points.size)
        for (i in 1 until points.size) c[i] = c[i - 1] + Geo.distance(points[i - 1], points[i])
        require(c.last() > 1.0) { "Route is too short" }
        route = points
        cum = c
        progress = 0.0
        dir = 1
        this.loop = loop
        speedKmh = kmh.coerceIn(0.5, 400.0)
        paused = false
        mode = Mode.ROUTE
        pos = points[0]
        bearing = Geo.bearing(points[0], points[1])
        lastTick = SystemClock.elapsedRealtime()
        push()
    }

    @Synchronized
    fun setSpeed(kmh: Double) {
        require(kmh.isFinite()) { "Invalid speed" }
        speedKmh = kmh.coerceIn(0.5, 400.0)
    }

    @Synchronized
    fun setPaused(p: Boolean) {
        paused = p
        lastTick = SystemClock.elapsedRealtime()
    }

    /** Ends the route and holds the current position. */
    @Synchronized
    fun stopRoute() {
        mode = if (pos != null) Mode.TELEPORT else Mode.IDLE
        paused = false
        route = emptyList()
        cum = DoubleArray(0)
    }

    @Synchronized
    fun status(): JSONObject = JSONObject().apply {
        put("enabled", started)
        put("mode", mode.name.lowercase())
        put("paused", paused)
        put("speedKmh", speedKmh)
        put("loop", loop)
        put("lat", pos?.lat ?: JSONObject.NULL)
        put("lng", pos?.lng ?: JSONObject.NULL)
        put("progress", if (mode == Mode.ROUTE && cum.isNotEmpty()) progress / cum.last() else 0.0)
    }

    @Synchronized
    private fun tick() {
        val now = SystemClock.elapsedRealtime()
        val dt = (now - lastTick) / 1000.0
        lastTick = now
        if (mode == Mode.ROUTE && !paused) advance(dt)
        push()
    }

    private fun advance(dt: Double) {
        val total = cum.last()
        progress += dir * (speedKmh / 3.6) * dt
        if (progress >= total) {
            if (loop) {
                progress = (2 * total - progress).coerceAtLeast(0.0)
                dir = -1
            } else {
                progress = total
                updatePos()
                mode = Mode.TELEPORT      // arrived: hold the final position
                route = emptyList()
                cum = DoubleArray(0)
                return
            }
        } else if (progress <= 0.0) {
            progress = (-progress).coerceAtMost(total)
            dir = 1
        }
        updatePos()
    }

    private fun updatePos() {
        var i = Arrays.binarySearch(cum, progress)
        if (i < 0) i = -i - 2
        i = i.coerceIn(0, route.size - 2)
        val segLen = cum[i + 1] - cum[i]
        val f = if (segLen > 0) ((progress - cum[i]) / segLen).coerceIn(0.0, 1.0) else 0.0
        val a = route[i]
        val b = route[i + 1]
        pos = LatLng(a.lat + (b.lat - a.lat) * f, a.lng + (b.lng - a.lng) * f)
        bearing = if (dir > 0) Geo.bearing(a, b) else Geo.bearing(b, a)
    }

    private fun push() {
        val p = pos ?: return
        if (!started) return
        val moving = mode == Mode.ROUTE && !paused
        val now = System.currentTimeMillis()
        for (prov in providers) {
            val l = Location(prov)
            l.latitude = p.lat
            l.longitude = p.lng
            l.altitude = 10.0
            l.accuracy = 5f
            l.speed = if (moving) (speedKmh / 3.6).toFloat() else 0f
            l.bearing = bearing
            l.time = now
            l.elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()
            if (Build.VERSION.SDK_INT >= 26) {
                l.verticalAccuracyMeters = 3f
                l.speedAccuracyMetersPerSecond = 1f
                l.bearingAccuracyDegrees = 10f
            }
            try {
                lm.setTestProviderLocation(prov, l)
            } catch (e: Exception) {
                Log.w(tag, "setTestProviderLocation($prov) failed: ${e.message}")
            }
        }
    }
}
