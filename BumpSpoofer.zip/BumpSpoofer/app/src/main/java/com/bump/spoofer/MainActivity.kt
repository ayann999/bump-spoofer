package com.bump.spoofer

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * One screen: a black and yellow start page, and once the engine runs,
 * a full-screen map (the bundled web UI inside a WebView) to control the location.
 */
class MainActivity : Activity() {

    private val yellow = Color.parseColor("#FFC400")
    private val black = Color.parseColor("#0A0A0A")
    private val grey = Color.parseColor("#9A9A9A")
    private val match = ViewGroup.LayoutParams.MATCH_PARENT
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var home: LinearLayout
    private lateinit var web: WebView
    private lateinit var startBtn: Button
    private lateinit var info: TextView
    private var loaded = false
    private var starting = false

    private val poll = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 700)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(filled: Boolean) = GradientDrawable().apply {
        cornerRadius = dp(18).toFloat()
        if (filled) {
            setColor(yellow)
        } else {
            setColor(Color.TRANSPARENT)
            setStroke(dp(2), yellow)
        }
    }

    private fun makeButton(label: String, filled: Boolean, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 17f
        b.typeface = Typeface.DEFAULT_BOLD
        b.setTextColor(if (filled) black else yellow)
        b.background = shape(filled)
        b.stateListAnimator = null
        b.setOnClickListener { onClick() }
        return b
    }

    private fun makeText(text: String, color: Int, size: Float): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(color)
        t.textSize = size
        t.gravity = Gravity.CENTER
        return t
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = black
        window.navigationBarColor = black

        val root = FrameLayout(this)
        root.setBackgroundColor(black)

        web = WebView(this)
        web.setBackgroundColor(black)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.visibility = View.GONE
        root.addView(web, FrameLayout.LayoutParams(match, match))

        home = LinearLayout(this)
        home.orientation = LinearLayout.VERTICAL
        home.gravity = Gravity.CENTER
        home.setPadding(dp(28), dp(28), dp(28), dp(28))

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_logo)
        home.addView(logo, LinearLayout.LayoutParams(dp(160), dp(160)))

        val title = makeText("BUMP SPOOFER", yellow, 30f)
        title.typeface = Typeface.DEFAULT_BOLD
        title.letterSpacing = 0.08f
        home.addView(title)

        val sub = makeText("Pick a spot on the map and your phone goes there.", grey, 15f)
        sub.setPadding(0, dp(8), 0, 0)
        home.addView(sub)

        info = makeText("", Color.WHITE, 14f)
        info.setPadding(0, dp(22), 0, 0)
        home.addView(info)

        startBtn = makeButton("Start", true) { startSpoofing() }
        home.addView(startBtn, LinearLayout.LayoutParams(match, dp(58)).apply { topMargin = dp(26) })

        home.addView(
            makeButton("Mock location setup", false) { openDeveloperOptions() },
            LinearLayout.LayoutParams(match, dp(54)).apply { topMargin = dp(12) }
        )

        val hint = makeText(
            "First time: Developer options > Select mock location app > Bump Spoofer.",
            grey, 12f
        )
        hint.setPadding(0, dp(16), 0, 0)
        home.addView(hint)

        root.addView(home, FrameLayout.LayoutParams(match, match))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        ui.post(poll)
    }

    override fun onPause() {
        ui.removeCallbacks(poll)
        super.onPause()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (web.visibility == View.VISIBLE) moveTaskToBack(true) else super.onBackPressed()
    }

    private fun startSpoofing() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
            requestPermissions(perms.toTypedArray(), 1)
            return
        }
        SpoofService.error = null
        starting = true
        startForegroundService(Intent(this, SpoofService::class.java))
        ui.postDelayed({ starting = false }, 8000)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            startSpoofing()
        } else {
            Toast.makeText(this, "Location permission is required to start", Toast.LENGTH_LONG).show()
        }
    }

    private fun openDeveloperOptions() {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        } catch (e: Exception) {
            Toast.makeText(this, "Turn on Developer options first (tap Build number 7 times)", Toast.LENGTH_LONG).show()
        }
    }

    private fun refresh() {
        if (SpoofService.running) {
            if (!loaded) {
                web.loadUrl("http://127.0.0.1:${SpoofService.PORT}/#pin=${Prefs.pin(this)}")
                loaded = true
            }
            starting = false
            web.visibility = View.VISIBLE
            home.visibility = View.GONE
        } else {
            if (loaded) {
                web.loadUrl("about:blank")
                loaded = false
            }
            web.visibility = View.GONE
            home.visibility = View.VISIBLE
            val err = SpoofService.error
            if (err != null) starting = false
            startBtn.isEnabled = !starting
            startBtn.text = if (starting) "Starting..." else "Start"
            info.text = err ?: "Ready when you are."
        }
    }
}
