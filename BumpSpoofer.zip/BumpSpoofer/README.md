# Bump Spoofer

Android mock-location app (Kotlin, no root) controlled from a browser over Wi-Fi.
The phone runs a small web server; open its address on your Windows PC and use the map.

Features: teleport, routes (footpaths / bike / roads / straight), adjustable speed, place search, history.

## Build

Requirements: JDK 17 and Android Studio (Koala or newer) or the Android SDK command-line tools.

**Android Studio**
1. File > Open > select the `BumpSpoofer` folder, wait for Gradle sync.
2. Plug in the phone (USB debugging on) and press Run, or Build > Build APK(s).

**Command line (Windows)**
```
gradle wrapper --gradle-version 8.7     (one time, needs Gradle installed)
gradlew.bat assembleDebug
adb install -r app\build\outputs\apk\debug\app-debug.apk
```
macOS/Linux: `./gradlew assembleDebug`.

## Phone setup (once)
1. Settings > About phone > tap Build number 7 times to enable Developer options.
2. Settings > Developer options > Select mock location app > **Bump Spoofer**.
3. Open Bump Spoofer, allow Location (and notifications), tap **Start server**.

## Use
1. Put the phone and PC on the same Wi-Fi (a phone hotspot also works).
2. On the PC open the address shown in the app (for example `http://192.168.1.23:8765`).
3. Enter the 6-digit PIN shown in the app.
4. Teleport: click the map or search, then "Teleport here".
   Route: switch to Route, click stops on the map, set speed, "Start route".
   Speed changes apply live. "Stop here" holds position. "Use real GPS" removes the mock.

## Notes
- The map, search and routing run in the PC browser and use OpenStreetMap services
  (tiles, Nominatim, routing.openstreetmap.de), so the PC needs internet. Please respect their usage policies.
- Traffic between the PC and phone is plain HTTP on your LAN, protected only by the PIN
  (10 wrong tries lock access for a minute). Use a network you trust.
- History is stored on the phone (`filesDir/history.json`, newest 200 entries).
- Some apps detect mock locations (`isMock`); this project makes no attempt to hide that.
- Intended for app testing, development and privacy. Do not use it to break an app's or service's terms, or to deceive others.

## Layout
```
app/src/main/java/com/bump/spoofer/
  MainActivity.kt        start/stop, address + PIN
  SpoofService.kt        foreground service (server + engine + locks)
  MockLocationEngine.kt  test providers, route playback at 1 Hz
  WebServer.kt           NanoHTTPD server, JSON API, PIN check
  HistoryStore.kt        JSON history
  Util.kt                geo math, IP lookup, PIN storage
app/src/main/assets/web/index.html   browser controller (Leaflet)
```

## API (header `X-Token: <PIN>`)
GET /api/status, GET /api/history, POST /api/teleport {lat,lng,label}, POST /api/route {points:[[lat,lng]],speedKmh,loop,label,meta},
POST /api/speed {speedKmh}, POST /api/pause, /api/resume, /api/stop, /api/release, /api/history/clear

## Phone-only workflow
Build in the cloud with GitHub Actions (upload BumpSpoofer.zip + .github/workflows/build.yml to a repo,
run the "Build APK" workflow, download the artifact), install the APK, then use
"Open controller on this phone" in the app. No PC needed.
