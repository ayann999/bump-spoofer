package com.bump.spoofer

import android.content.Context
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.Method
import fi.iki.elonen.NanoHTTPD.Response
import org.json.JSONObject
import java.security.MessageDigest
import java.util.Locale

/**
 * Tiny HTTP server inside the app. "/" serves the controller page from assets,
 * "/api/*" is a JSON API protected by the PIN shown on the phone (header X-Token).
 */
class WebServer(
    private val ctx: Context,
    port: Int,
    private val engine: MockLocationEngine,
    private val history: HistoryStore,
    private val pin: () -> String
) : NanoHTTPD(port) {

    private var fails = 0
    private var windowStart = 0L

    override fun serve(session: IHTTPSession): Response = try {
        val uri = session.uri
        when {
            uri.startsWith("/api/") -> api(session)
            uri == "/" || uri == "/index.html" -> page()
            else -> json(404, err("Not found"))
        }
    } catch (e: SecurityException) {
        json(403, err("Bump Spoofer is not the selected mock location app (Developer options)"))
    } catch (e: Exception) {
        json(400, err(e.message ?: e.javaClass.simpleName))
    }

    private fun page(): Response {
        val html = ctx.assets.open("web/index.html").bufferedReader().use { it.readText() }
        return newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", html)
    }

    @Synchronized
    private fun authorized(s: IHTTPSession): Boolean {
        val now = System.currentTimeMillis()
        if (now - windowStart > 60_000) { windowStart = now; fails = 0 }
        if (fails >= 10) return false                       // locked for the rest of this minute
        val given = (s.headers["x-token"] ?: "").toByteArray()
        val ok = MessageDigest.isEqual(given, pin().toByteArray())
        if (!ok) fails++
        return ok
    }

    private fun readBody(s: IHTTPSession): JSONObject {
        val files = HashMap<String, String>()
        s.parseBody(files)
        return JSONObject(files["postData"] ?: "{}")
    }

    private fun checkCoord(lat: Double, lng: Double) {
        require(lat in -90.0..90.0 && lng in -180.0..180.0) { "Coordinates out of range" }
    }

    private fun api(s: IHTTPSession): Response {
        if (!authorized(s)) return json(401, err("Wrong PIN (10 wrong tries locks access for a minute)"))
        val body = if (s.method == Method.POST) readBody(s) else JSONObject()

        when (s.uri) {
            "/api/status" -> return json(200, engine.status())

            "/api/teleport" -> {
                val lat = body.getDouble("lat")
                val lng = body.getDouble("lng")
                checkCoord(lat, lng)
                engine.teleport(lat, lng)
                history.add(JSONObject()
                    .put("type", "teleport")
                    .put("lat", lat).put("lng", lng)
                    .put("label", body.optString("label", String.format(Locale.US, "%.5f, %.5f", lat, lng))))
            }

            "/api/route" -> {
                val arr = body.getJSONArray("points")
                require(arr.length() in 2..20000) { "A route needs 2 to 20000 points" }
                val pts = (0 until arr.length()).map {
                    val a = arr.getJSONArray(it)
                    LatLng(a.getDouble(0), a.getDouble(1)).also { p -> checkCoord(p.lat, p.lng) }
                }
                val kmh = body.optDouble("speedKmh", 5.0)
                val loop = body.optBoolean("loop", false)
                engine.startRoute(pts, kmh, loop)
                history.add(JSONObject()
                    .put("type", "route")
                    .put("label", body.optString("label", "Route"))
                    .put("speedKmh", kmh).put("loop", loop)
                    .put("lat", pts[0].lat).put("lng", pts[0].lng)
                    .put("meta", body.optJSONObject("meta") ?: JSONObject()))
            }

            "/api/speed" -> engine.setSpeed(body.getDouble("speedKmh"))
            "/api/pause" -> engine.setPaused(true)
            "/api/resume" -> engine.setPaused(false)
            "/api/stop" -> engine.stopRoute()
            "/api/release" -> engine.disable()
            "/api/history" -> return json(200, JSONObject().put("items", history.all()))
            "/api/history/clear" -> history.clear()
            else -> return json(404, err("Unknown endpoint"))
        }
        return json(200, JSONObject().put("ok", true))
    }

    private fun err(msg: String) = JSONObject().put("error", msg)

    private fun json(code: Int, obj: JSONObject): Response {
        val r = newFixedLengthResponse(Response.Status.lookup(code), "application/json; charset=utf-8", obj.toString())
        r.addHeader("Cache-Control", "no-store")
        return r
    }
}
