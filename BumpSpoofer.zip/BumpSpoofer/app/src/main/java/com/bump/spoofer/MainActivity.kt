package com.bump.spoofer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var toggle: Button

    private val poll = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply { text = "Bump Spoofer"; textSize = 26f })
        status = TextView(this).apply { textSize = 16f; setPadding(0, pad, 0, pad) }
        root.addView(status)
        toggle = Button(this).apply { setOnClickListener { onToggle() } }
        root.addView(toggle)
        root.addView(Button(this).apply {
            text = "Open controller on this phone"
            setOnClickListener { openController() }
        })
        root.addView(Button(this).apply {
            text = "Open developer options"
            setOnClickListener { openDeveloperOptions() }
        })
        root.addView(Button(this).apply {
            text = "Generate new PIN"
            setOnClickListener { Prefs.newPin(this@MainActivity); refresh() }
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        ui.post(poll)
    }

    override fun onPause() {
        ui.removeCallbacks(poll)
        super.onPause()
    }

    private fun onToggle() {
        if (SpoofService.running) {
            startService(Intent(this, SpoofService::class.java).setAction(SpoofService.ACTION_STOP))
            return
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
            requestPermissions(perms.toTypedArray(), 1)
            return
        }
        startForegroundService(Intent(this, SpoofService::class.java))
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            onToggle()
        } else {
            Toast.makeText(this, "Location permission is required to start", Toast.LENGTH_LONG).show()
        }
    }

    private fun openController() {
        if (!SpoofService.running) {
            Toast.makeText(this, "Start the server first", Toast.LENGTH_SHORT).show()
            return
        }
        val url = "http://127.0.0.1:${SpoofService.PORT}/#pin=${Prefs.pin(this)}"
        try {
            startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, "No browser found", Toast.LENGTH_LONG).show()
        }
    }

    private fun openDeveloperOptions() {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        } catch (e: Exception) {
            Toast.makeText(this, "Enable Developer options first (tap Build number 7 times)", Toast.LENGTH_LONG).show()
        }
    }

    private fun refresh() {
        val running = SpoofService.running
        toggle.text = if (running) "Stop server" else "Start server"
        val sb = StringBuilder()
        sb.append(if (running) "Server: running\n\n" else "Server: stopped\n\n")
        if (running) {
            sb.append("Open on your PC:\nhttp://${Net.localIp() ?: "<phone-ip>"}:${SpoofService.PORT}\n\n")
            sb.append("PIN: ${Prefs.pin(this)}\n\n")
        }
        SpoofService.error?.let { sb.append("Error: $it\n\n") }
        sb.append("Setup: Settings > Developer options > Select mock location app > Bump Spoofer. " +
                  "Phone and PC must be on the same Wi-Fi.")
        status.text = sb
    }
}
