package com.bump.spoofer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import fi.iki.elonen.NanoHTTPD

class SpoofService : Service() {

    companion object {
        const val PORT = 8765
        const val ACTION_STOP = "com.bump.spoofer.STOP"
        private const val CHANNEL = "bump"

        @Volatile var running = false
        @Volatile var error: String? = null
    }

    private var engine: MockLocationEngine? = null
    private var server: WebServer? = null
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            stopSelf()
            return START_NOT_STICKY
        }
        goForeground()
        if (!running) startAll()
        return START_STICKY
    }

    private fun startAll() {
        error = null
        try {
            val e = MockLocationEngine(this)
            engine = e
            e.enable()                                  // fails fast if we are not the mock location app
            val s = WebServer(this, PORT, e, HistoryStore(this)) { Prefs.pin(this) }
            s.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
            server = s
            acquireLocks()
            running = true
        } catch (ex: SecurityException) {
            error = "Bump Spoofer is not the mock location app. Developer options > Select mock location app."
            shutdown(); stopSelf()
        } catch (ex: Exception) {
            error = ex.message ?: ex.javaClass.simpleName
            shutdown(); stopSelf()
        }
    }

    private fun acquireLocks() {
        wake = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "bump:service").apply { acquire() }
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                   else WifiManager.WIFI_MODE_FULL_HIGH_PERF
        wifi = wm.createWifiLock(mode, "bump:wifi").apply { acquire() }
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Bump Spoofer", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, SpoofService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Bump Spoofer is running")
            .setContentText("Controller on port $PORT")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(1, n)
        }
    }

    private fun shutdown() {
        try { server?.stop() } catch (e: Exception) { /* ignore */ }
        try { engine?.shutdown() } catch (e: Exception) { /* ignore */ }
        server = null
        engine = null
        try { wake?.release() } catch (e: Exception) { /* ignore */ }
        try { wifi?.release() } catch (e: Exception) { /* ignore */ }
        wake = null
        wifi = null
        running = false
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }
}
