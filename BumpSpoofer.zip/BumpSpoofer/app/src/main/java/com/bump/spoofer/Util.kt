package com.bump.spoofer

import android.content.Context
import java.net.Inet4Address
import java.net.NetworkInterface
import java.security.SecureRandom
import java.util.Locale
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

data class LatLng(val lat: Double, val lng: Double)

object Geo {
    private const val R = 6371000.0
    private fun rad(d: Double) = Math.toRadians(d)

    /** Great-circle distance in metres. */
    fun distance(a: LatLng, b: LatLng): Double {
        val dLat = rad(b.lat - a.lat)
        val dLng = rad(b.lng - a.lng)
        val h = sin(dLat / 2).pow(2) + cos(rad(a.lat)) * cos(rad(b.lat)) * sin(dLng / 2).pow(2)
        return 2 * R * asin(min(1.0, sqrt(h)))
    }

    /** Initial bearing a -> b in degrees (0..360). */
    fun bearing(a: LatLng, b: LatLng): Float {
        val p1 = rad(a.lat)
        val p2 = rad(b.lat)
        val dl = rad(b.lng - a.lng)
        val y = sin(dl) * cos(p2)
        val x = cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl)
        return ((Math.toDegrees(atan2(y, x)) + 360.0) % 360.0).toFloat()
    }
}

object Net {
    /** First private IPv4 address of this phone (Wi-Fi or hotspot). */
    fun localIp(): String? = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { it is Inet4Address && !it.isLoopbackAddress && it.isSiteLocalAddress }
            ?.hostAddress
    } catch (e: Exception) {
        null
    }
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("bump", Context.MODE_PRIVATE)

    fun pin(c: Context): String = sp(c).getString("pin", null) ?: newPin(c)

    fun newPin(c: Context): String {
        val p = String.format(Locale.US, "%06d", SecureRandom().nextInt(1_000_000))
        sp(c).edit().putString("pin", p).apply()
        return p
    }
}
